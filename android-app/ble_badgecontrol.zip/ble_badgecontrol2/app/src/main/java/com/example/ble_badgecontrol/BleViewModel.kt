package com.example.ble_badgecontrol

import android.annotation.SuppressLint
import android.app.Application
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.welie.blessed.BluetoothCentralManager
import com.welie.blessed.BluetoothCentralManagerCallback
import com.welie.blessed.BluetoothPeripheral
import com.welie.blessed.BluetoothPeripheralCallback
import com.welie.blessed.GattStatus
import com.welie.blessed.HciStatus
import com.welie.blessed.WriteType
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

data class LogMessage(
    val text: String,
    val isSent: Boolean
)

data class ImageStatus(
    val imageIndex: Int,
    val isSuccess: Boolean
)

sealed class OtaState {
    object Idle : OtaState()
    object Starting : OtaState()
    object WaitingReady : OtaState()
    data class Progress(val bytesSent: Int, val totalBytes: Int) : OtaState()
    object Success : OtaState()
    data class Error(val message: String) : OtaState()
}

class BleViewModel(application: Application) : AndroidViewModel(application) {

    private val SERVICE_UUID: UUID = UUID.fromString("6E400001-B5A3-F393-E0A9-E50E24DCCA9E")
    private val CHAR_RX_UUID: UUID = UUID.fromString("6E400002-B5A3-F393-E0A9-E50E24DCCA9E")
    private val CHAR_TX_UUID: UUID = UUID.fromString("6E400003-B5A3-F393-E0A9-E50E24DCCA9E")

    // UUID для отправки бинарных данных OTA
    private val OTA_DATA_UUID: UUID = UUID.fromString("6E400004-B5A3-F393-E0A9-E50E24DCCA9E")

    private val _bleState = MutableStateFlow<BleState>(BleState.Disconnected)
    val bleState: StateFlow<BleState> = _bleState.asStateFlow()

    private val _serialNumber = MutableStateFlow<String?>(null)
    val serialNumber: StateFlow<String?> = _serialNumber.asStateFlow()

    private val _lastResponse = MutableStateFlow<String?>(null)
    val lastResponse: StateFlow<String?> = _lastResponse.asStateFlow()

    private val _imageStatus = MutableStateFlow<ImageStatus?>(null)
    val imageStatus: StateFlow<ImageStatus?> = _imageStatus.asStateFlow()

    private val _logs = MutableStateFlow<List<LogMessage>>(emptyList())
    val logs: StateFlow<List<LogMessage>> = _logs.asStateFlow()

    private val _otaState = MutableStateFlow<OtaState>(OtaState.Idle)
    val otaState: StateFlow<OtaState> = _otaState.asStateFlow()

    private var connectedPeripheral: BluetoothPeripheral? = null
    private var selectedIndex: Int = -1
    private var errorTimerJob: Job? = null
    private var otaJob: Job? = null
    private var reconnectJob: Job? = null
    private var shouldMaintainConnection = false
    private var hasConnectedBefore = false

    private val rxBuffer = StringBuilder()
    private var flushRunnable: Runnable? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    private val _isBluetoothEnabled = MutableStateFlow(true)
    val isBluetoothEnabled: StateFlow<Boolean> = _isBluetoothEnabled.asStateFlow()

    private val bluetoothAdapter: BluetoothAdapter? by lazy {
        val bluetoothManager = getApplication<Application>().getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothManager.adapter
    }

    private val centralManager: BluetoothCentralManager by lazy {
        BluetoothCentralManager(
            getApplication(),
            centralManagerCallback,
            BleConfig.getHandler()
        )
    }

    fun checkBluetoothStatus(): Boolean {
        val isEnabled = bluetoothAdapter?.isEnabled == true
        _isBluetoothEnabled.value = isEnabled
        return isEnabled
    }

    fun addLog(text: String, isSent: Boolean) {
        val newLog = LogMessage(text = text, isSent = isSent)
        _logs.update { currentLogs -> currentLogs + newLog }
    }

    private fun onBytesReceived(bytes: ByteArray) {
        var incomingText = String(bytes, Charsets.UTF_8)

        incomingText = incomingText
            .replace("^J", "\n")
            .replace("\u000A", "\n")
            .replace("\r\n", "\n")
            .replace("\r", "\n")
            .replace("\u0000", "")

        rxBuffer.append(incomingText)

        while (rxBuffer.contains("\n")) {
            val newlineIndex = rxBuffer.indexOf("\n")
            val line = rxBuffer.substring(0, newlineIndex)

            processReceivedLine(line)

            rxBuffer.delete(0, newlineIndex + 1)
        }

        scheduleBufferFlush()
    }

    private fun scheduleBufferFlush() {
        flushRunnable?.let { mainHandler.removeCallbacks(it) }
        flushRunnable = Runnable {
            if (rxBuffer.isNotEmpty()) {
                val remainingText = rxBuffer.toString()
                if (remainingText.isNotBlank()) {
                    processReceivedLine(remainingText)
                }
                rxBuffer.clear()
            }
        }
        mainHandler.postDelayed(flushRunnable!!, 50)
    }

    private fun processReceivedLine(line: String) {
        _lastResponse.value = line
        addLog(line, isSent = false)

        val cleanData = line.trim()

        if (cleanData.startsWith("SN-")) {
            _serialNumber.value = cleanData
        } else if (cleanData == "OK" || cleanData == "1") {
            errorTimerJob?.cancel()
            _imageStatus.value = ImageStatus(imageIndex = selectedIndex, isSuccess = true)
        } else if (cleanData == "ERROR" || cleanData == "0") {
            errorTimerJob?.cancel()
            _imageStatus.value = ImageStatus(imageIndex = selectedIndex, isSuccess = false)

            errorTimerJob = viewModelScope.launch {
                delay(3000)
                if (_imageStatus.value?.isSuccess == false) {
                    _imageStatus.value = null
                }
            }
        }
    }

    // --- OTA Firmware Update Logic ---

    fun startOtaUpdate(fileBytes: ByteArray) {
        if (connectedPeripheral == null || _bleState.value !is BleState.Connected) {
            _otaState.value = OtaState.Error("Устройство не подключено")
            return
        }

        otaJob?.cancel()
        otaJob = viewModelScope.launch {
            try {
                _otaState.value = OtaState.Starting
                val totalSize = fileBytes.size
                val startCommand = "START 0000 $totalSize"

                // 1. Шлем START 0000 <размер>
                sendCommand(startCommand)
                _otaState.value = OtaState.WaitingReady

                // 2. Ждем ответ "READY"
                val readyReceived = waitForResponse("READY", timeoutMs = 10000)
                if (!readyReceived) {
                    _otaState.value = OtaState.Error("Не получен ответ READY")
                    return@launch
                }

                // 3. Отправляем сырой .bin байт за байтом (или блоками) в OTA_DATA_UUID
                val peripheral = connectedPeripheral ?: return@launch
                val chunkSize = 128 // Оптимальный размер пакета для BLE (с учетом MTU)
                var offset = 0

                while (offset < totalSize) {
                    val end = (offset + chunkSize).coerceAtMost(totalSize)
                    val chunk = fileBytes.copyOfRange(offset, end)

                    // Запись блока
                    peripheral.writeCharacteristic(
                        SERVICE_UUID,
                        OTA_DATA_UUID,
                        chunk,
                        WriteType.WITHOUT_RESPONSE // Или WITH_RESPONSE в зависимости от вашей реализации устройства
                    )

                    offset = end
                    _otaState.value = OtaState.Progress(offset, totalSize)
                    delay(15) // Небольшая задержка, чтобы не перегрузить BLE-стек
                }

                // 4. Ждем ответ PROGRESS <размер>/<размер>
                val expectedProgress = "PROGRESS $totalSize/$totalSize"
                val progressReceived = waitForResponse(expectedProgress, timeoutMs = 15000)
                if (!progressReceived) {
                    _otaState.value = OtaState.Error("Не получен PROGRESS $totalSize/$totalSize")
                    return@launch
                }

                // 5. Отправляем END
                sendCommand("END")

                // 6. Ждем ответ OK rebooting
                val rebootReceived = waitForResponse("OK rebooting", timeoutMs = 5000)
                if (rebootReceived) {
                    _otaState.value = OtaState.Success
                } else {
                    _otaState.value = OtaState.Error("Устройство не подтвердило перезагрузку")
                }

            } catch (e: Exception) {
                _otaState.value = OtaState.Error("Ошибка OTA: ${e.localizedMessage}")
            }
        }
    }

    private suspend fun waitForResponse(expectedSubstring: String, timeoutMs: Long): Boolean {
        val startTime = System.currentTimeMillis()
        while (System.currentTimeMillis() - startTime < timeoutMs) {
            val response = _lastResponse.value
            if (response != null && response.contains(expectedSubstring)) {
                return true
            }
            delay(100)
        }
        return false
    }

    fun resetOtaState() {
        _otaState.value = OtaState.Idle
    }

    // ------------------------------------

    fun onDeviceConnected() {
        sendCommand("get_sn")
    }

    fun onDataReceived(data: String) {
        if (data.startsWith("SN:")) {
            _serialNumber.value = data.removePrefix("SN:").trim()
        }
    }

    fun onDisconnected() {
        _serialNumber.value = null
    }

    @SuppressLint("MissingPermission")
    fun toggleConnection() {
        if (!checkBluetoothStatus()) return

        when (_bleState.value) {
            is BleState.Connected, is BleState.Scanning, is BleState.Connecting -> {
                disconnect()
            }
            else -> {
                shouldMaintainConnection = true
                startConnectionService()
                startSafeScan()
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun startSafeScan() {
        if (!checkBluetoothStatus()) return
        if (_bleState.value is BleState.Scanning || _bleState.value is BleState.Connecting) return

        _bleState.value = BleState.Scanning
        try {
            centralManager.scanForPeripheralsWithServices(arrayOf(SERVICE_UUID))
        } catch (e: Exception) {
            _bleState.value = BleState.Disconnected
            scheduleReconnect()
        }
    }

    @SuppressLint("MissingPermission")
    fun disconnect() {
        shouldMaintainConnection = false
        reconnectJob?.cancel()
        centralManager.stopScan()
        connectedPeripheral?.let {
            centralManager.cancelConnection(it)
        }
        _bleState.value = BleState.Disconnected
        _serialNumber.value = null
        stopConnectionService()
    }

    fun sendClearCommand() {
        sendCommand("clear")
    }

    fun sendResetCommand() {
        sendCommand("reset")
    }

    fun disconnectAndExit() {
        disconnect()
    }

    private fun startConnectionService() {
        val context = getApplication<Application>()
        try {
            ContextCompat.startForegroundService(context, Intent(context, BleConnectionService::class.java))
        } catch (_: SecurityException) {
            // The app remains usable in foreground when notification-related permissions are denied.
        }
    }

    private fun stopConnectionService() {
        val context = getApplication<Application>()
        context.stopService(Intent(context, BleConnectionService::class.java))
    }

    private fun scheduleReconnect() {
        if (!shouldMaintainConnection || !checkBluetoothStatus()) return

        reconnectJob?.cancel()
        reconnectJob = viewModelScope.launch {
            delay(RECONNECT_DELAY_MS)
            if (shouldMaintainConnection && _bleState.value is BleState.Disconnected) {
                startSafeScan()
            }
        }
    }

    fun sendCommand(command: String) {
        val peripheral = connectedPeripheral

        addLog(text = command.trim(), isSent = true)

        if (peripheral == null || _bleState.value !is BleState.Connected) {
            return
        }

        val bytes = "$command\n".toByteArray(Charsets.UTF_8)
        peripheral.writeCharacteristic(
            SERVICE_UUID,
            CHAR_RX_UUID,
            bytes,
            WriteType.WITH_RESPONSE
        )
    }

    fun sendImageCommand(index: Int, command: String) {
        selectedIndex = index
        if (_imageStatus.value?.imageIndex != index) {
            _imageStatus.value = null
        }
        sendCommand(command)
    }

    private val centralManagerCallback = object : BluetoothCentralManagerCallback() {
        override fun onDiscoveredPeripheral(peripheral: BluetoothPeripheral, scanResult: ScanResult) {
            _bleState.value = BleState.Connecting
            centralManager.stopScan()
            centralManager.connectPeripheral(peripheral, peripheralCallback)
        }

        override fun onDisconnectedPeripheral(peripheral: BluetoothPeripheral, status: HciStatus) {
            connectedPeripheral = null
            _bleState.value = BleState.Disconnected
            _lastResponse.value = null
            _serialNumber.value = null
            scheduleReconnect()
        }
    }

    private val peripheralCallback = object : BluetoothPeripheralCallback() {
        override fun onServicesDiscovered(peripheral: BluetoothPeripheral) {
            connectedPeripheral = peripheral
            _bleState.value = BleState.Connected(peripheral.name.ifEmpty { "LogoBadge" })
            peripheral.setNotify(SERVICE_UUID, CHAR_TX_UUID, true)

            sendCommand("get_sn")
            // On a reconnection restore Ford. Its existing OK handler will mark the card as
            // INSTALLED only after the device acknowledges "show 0ford.bin".
            if (hasConnectedBefore) {
                mainHandler.postDelayed({
                    if (_bleState.value is BleState.Connected) {
                        sendImageCommand(FORD_IMAGE_INDEX, FORD_COMMAND)
                    }
                }, RESTORE_LOGO_DELAY_MS)
            }
            hasConnectedBefore = true
        }

        override fun onCharacteristicUpdate(
            peripheral: BluetoothPeripheral,
            value: ByteArray,
            characteristic: BluetoothGattCharacteristic,
            status: GattStatus
        ) {
            if (status == GattStatus.SUCCESS) {
                mainHandler.post {
                    onBytesReceived(value)
                }
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        disconnect()
    }
}

object BleConfig {
    private val handler = Handler(Looper.getMainLooper())
    fun getHandler(): Handler = handler
}

private const val FORD_IMAGE_INDEX = 8
private const val FORD_COMMAND = "show 0ford.bin"
private const val RECONNECT_DELAY_MS = 2_000L
private const val RESTORE_LOGO_DELAY_MS = 300L
