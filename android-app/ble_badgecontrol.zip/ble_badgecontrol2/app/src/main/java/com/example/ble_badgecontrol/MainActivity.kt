package com.example.ble_badgecontrol

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Build.VERSION.SDK_INT
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.ImageLoader
import coil.compose.AsyncImage
import coil.decode.GifDecoder
import coil.decode.ImageDecoderDecoder

// Модель для индивидуальной карточки
data class BadgeItem(
    val id: Int,             // Уникальный ID
    val title: String,       // Заголовок
    val imageResId: Int,     // Картинка из res/drawable
    val command: String,     // Базовая команда BLE
    val hasColorPicker: Boolean = false // Нужен ли выбор цвета
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF121212)
                ) {
                    PermissionRequester {
                        SmartMainScreen()
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------------
// ВСПОМОГАТЕЛЬНАЯ ФУНКЦИЯ ДЛЯ КОНВЕРТАЦИИ В RGB565 (напр. Red -> "F800")
// -------------------------------------------------------------------
fun Color.toRgb565Hex(): String {
    val r = (red * 31).toInt() and 0x1F
    val g = (green * 63).toInt() and 0x3F
    val b = (blue * 31).toInt() and 0x1F
    val rgb565 = (r shl 11) or (g shl 5) or b
    return String.format("%04X", rgb565)
}

// -------------------------------------------------------------------
// НАСТРОЙКА КАРТОЧЕК ДЛЯ КАЖДОЙ СТРАНИЦЫ
// -------------------------------------------------------------------
fun getPageItems(pageIndex: Int): List<BadgeItem> {
    return when (pageIndex) {
        0 -> listOf(
            BadgeItem(1, "BMW", R.drawable.img1, "show s1.bin"),
            BadgeItem(2, "Mercedes", R.drawable.img2, "show s2.bin"),
            BadgeItem(3, "AlfaRomeo", R.drawable.img3, "show s3.bin"),
            BadgeItem(4, "Porsche", R.drawable.img4, "show s4.bin"),
            BadgeItem(5, "Nissan", R.drawable.nissan, "show nissan.bin"),
            BadgeItem(6, "Toyota", R.drawable.toyota, "show toyota.bin"),
            BadgeItem(7, "Chevrolet", R.drawable.chevrolet, "show chevrolet.bin"),
            BadgeItem(8, "Ford", R.drawable.ford, "show 0ford.bin"),
            BadgeItem(9, "Honda", R.drawable.honda, "show honda.bin"),
            BadgeItem(10, "Hyondai", R.drawable.hyondai, "show hyondai.bin"),
            BadgeItem(11, "Fiat", R.drawable.fiat, "show fiat.bin"),
            BadgeItem(12, "VolksWagen", R.drawable.vw, "show vw.bin"),
            BadgeItem(13, "LandRover", R.drawable.landrover, "show landrover.bin"),
            BadgeItem(14, "peugeot", R.drawable.peugeot, "show peugeot.bin"),
            BadgeItem(15, "renault", R.drawable.renault, "show renault.bin"),
            BadgeItem(16, "volvo", R.drawable.volvo, "show volvo.bin")
        )
        1 -> listOf(
            BadgeItem(17, "Eye", R.drawable.anim1, "show anim1"),
            BadgeItem(18, "Kiss", R.drawable.anim2, "show anim2"),
            BadgeItem(19, "AnimEye", R.drawable.anim3, "show anim3", hasColorPicker = true)
        )
        2 -> listOf(
            BadgeItem(20, "CoolF", R.drawable.joia_f, "show joia_f.bin"),
            BadgeItem(21, "CoolM", R.drawable.joia_m, "show joia_m.bin")
        )
        else -> listOf(
            BadgeItem(22, "Clear Screen", R.drawable.clear, "clear"),
            BadgeItem(23, "Bandeira BR", R.drawable.br, "show br.bin"),
            BadgeItem(24, "Pain", R.drawable.pain, "show s5.bin")
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SmartMainScreen(
    viewModel: BleViewModel = viewModel()
) {
    val bleState by viewModel.bleState.collectAsState()
    val imageStatus by viewModel.imageStatus.collectAsState()
    val isBluetoothEnabled by viewModel.isBluetoothEnabled.collectAsState()
    val serialNumber by viewModel.serialNumber.collectAsState()
    val otaState by viewModel.otaState.collectAsState()

    val context = LocalContext.current
    val activity = (context as? Activity)
    val lifecycleOwner = LocalLifecycleOwner.current

    var menuExpanded by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }
    var showResetDialog by remember { mutableStateOf(false) }
    var showTerminalDialog by remember { mutableStateOf(false) }

    // Лаунчер для выбора бинарного файла .bin
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { fileUri ->
            val bytes = context.contentResolver.openInputStream(fileUri)?.use { it.readBytes() }
            if (bytes != null) {
                viewModel.startOtaUpdate(bytes)
            }
        }
    }

    // Переменная для карточки, требующей выбор цвета
    var colorPickerItem by remember { mutableStateOf<BadgeItem?>(null) }

    val pageTitles = remember { listOf("Auto", "Animation", "Emoji", "Other") }
    val pagerState = rememberPagerState(pageCount = { pageTitles.size })

    // Единый ImageLoader для поддержки GIF/анимаций
    val gifImageLoader = remember(context) {
        ImageLoader.Builder(context)
            .components {
                if (SDK_INT >= 28) {
                    add(ImageDecoderDecoder.Factory())
                } else {
                    add(GifDecoder.Factory())
                }
            }
            .build()
    }

    // Авто-проверка статуса Bluetooth при сворачивании/разворачивании приложения
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                viewModel.checkBluetoothStatus()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    // Всплывающее диалоговое окно, если Bluetooth выключен
    if (!isBluetoothEnabled) {
        AlertDialog(
            onDismissRequest = { },
            title = {
                Text(text = "Bluetooth is disabled", fontWeight = FontWeight.Bold)
            },
            text = {
                Text("To scan the badge board need to enable Bluetooth adapter.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
                        context.startActivity(intent)
                    }
                ) {
                    Text("Enable by configuration menu")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { viewModel.checkBluetoothStatus() }
                ) {
                    Text("Check again")
                }
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E2C))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Кнопка меню
                Box {
                    IconButton(onClick = { menuExpanded = true }) {
                        Icon(
                            imageVector = Icons.Default.Menu,
                            contentDescription = "Menu",
                            tint = Color.White
                        )
                    }

                    DropdownMenu(
                        expanded = menuExpanded,
                        onDismissRequest = { menuExpanded = false },
                        modifier = Modifier.background(Color(0xFF2A2A3C))
                    ) {
                        DropdownMenuItem(
                            text = { Text("Terminal", color = Color.White) },
                            onClick = {
                                menuExpanded = false
                                showTerminalDialog = true
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Update", color = Color.White) },
                            onClick = {
                                menuExpanded = false
                                filePickerLauncher.launch("*/*")
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Reset", color = Color.White) },
                            onClick = {
                                menuExpanded = false
                                showResetDialog = true
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("About", color = Color.White) },
                            onClick = {
                                menuExpanded = false
                                showAboutDialog = true
                            }
                        )
                        HorizontalDivider(color = Color.DarkGray)
                        DropdownMenuItem(
                            text = { Text("Exit", color = Color(0xFFFF5252)) },
                            onClick = {
                                menuExpanded = false
                                viewModel.disconnectAndExit()
                                activity?.finish()
                            }
                        )
                    }
                }

                // Блок названия устройства, статуса и серийного номера
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = when (val state = bleState) {
                            is BleState.Disconnected -> "Disabled"
                            is BleState.Scanning -> "Scanning device..."
                            is BleState.Connecting -> "Connection..."
                            is BleState.Connected -> state.deviceName
                            is BleState.Error -> "Connection error"
                        },
                        color = when (bleState) {
                            is BleState.Connected -> Color.Green
                            is BleState.Scanning, is BleState.Connecting -> Color.Yellow
                            else -> Color.Gray
                        },
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )

                    if (bleState is BleState.Connected && !serialNumber.isNullOrEmpty()) {
                        Text(
                            text = "S/N: $serialNumber",
                            color = Color.LightGray,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Normal,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                }

                // Кнопка подключения/отключения
                Button(
                    onClick = { viewModel.toggleConnection() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (bleState is BleState.Connected) Color(0xFFD32F2F) else Color(0xFF1976D2)
                    ),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = when (bleState) {
                            is BleState.Connected -> "Disable"
                            is BleState.Scanning, is BleState.Connecting -> "Cancel"
                            else -> "Connect"
                        },
                        fontSize = 12.sp
                    )
                }
            }
        }

        Text(
            text = pageTitles.getOrElse(pagerState.currentPage) { "" },
            color = Color.White,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        HorizontalPager(
            state = pagerState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) { page ->
            PageGrid(
                pageIndex = page,
                imageStatus = imageStatus,
                imageLoader = gifImageLoader,
                onItemClick = { item ->
                    if (item.hasColorPicker) {
                        colorPickerItem = item
                    } else {
                        viewModel.sendImageCommand(item.id, item.command)
                    }
                }
            )
        }

        Row(
            modifier = Modifier
                .padding(top = 8.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            repeat(pageTitles.size) { iteration ->
                val color = if (pagerState.currentPage == iteration) Color(0xFF1976D2) else Color.DarkGray
                Box(
                    modifier = Modifier
                        .padding(4.dp)
                        .clip(CircleShape)
                        .background(color)
                        .size(10.dp)
                )
            }
        }
    }

    // Обработка вариантов отображения состояния OTA
    when (val state = otaState) {
        is OtaState.Starting, is OtaState.WaitingReady, is OtaState.Progress -> {
            AlertDialog(
                onDismissRequest = { },
                title = { Text("Firmware Update", color = Color.White, fontWeight = FontWeight.Bold) },
                text = {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        when (state) {
                            is OtaState.Starting -> Text("Preparing file...", color = Color.LightGray)
                            is OtaState.WaitingReady -> Text("Waiting for READY...", color = Color.LightGray)
                            is OtaState.Progress -> {
                                val progressFloat = state.bytesSent.toFloat() / state.totalBytes
                                val percent = (progressFloat * 100).toInt()

                                Text("Uploading: $percent%", color = Color.White, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(12.dp))
                                LinearProgressIndicator(
                                    progress = { progressFloat },
                                    modifier = Modifier.fillMaxWidth(),
                                    color = Color(0xFF1976D2)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("${state.bytesSent} / ${state.totalBytes} B", color = Color.Gray, fontSize = 12.sp)
                            }
                            else -> {}
                        }
                    }
                },
                containerColor = Color(0xFF1E1E2C),
                confirmButton = {}
            )
        }
        is OtaState.Success -> {
            AlertDialog(
                onDismissRequest = { viewModel.resetOtaState() },
                title = { Text("Update Finished", color = Color.Green, fontWeight = FontWeight.Bold) },
                text = { Text("Firmware downloaded successfully. Device rebooting...", color = Color.LightGray) },
                containerColor = Color(0xFF1E1E2C),
                confirmButton = {
                    Button(onClick = { viewModel.resetOtaState() }) {
                        Text("OK")
                    }
                }
            )
        }
        is OtaState.Error -> {
            AlertDialog(
                onDismissRequest = { viewModel.resetOtaState() },
                title = { Text("OTA Error", color = Color(0xFFFF5252), fontWeight = FontWeight.Bold) },
                text = { Text(state.message, color = Color.LightGray) },
                containerColor = Color(0xFF1E1E2C),
                confirmButton = {
                    Button(onClick = { viewModel.resetOtaState() }) {
                        Text("OK")
                    }
                }
            )
        }
        OtaState.Idle -> {}
    }

    // Показ диалога выбора цвета для карточек с палитрой
    colorPickerItem?.let { item ->
        ColorPickerDialog(
            defaultColorHex = "F800",
            onColorSelected = { hexColor ->
                val fullCommand = "${item.command} $hexColor"
                viewModel.sendImageCommand(item.id, fullCommand)
                colorPickerItem = null
            },
            onDismiss = {
                val defaultCommand = "${item.command} F800"
                viewModel.sendImageCommand(item.id, defaultCommand)
                colorPickerItem = null
            }
        )
    }

    if (showAboutDialog) {
        Dialog(onDismissRequest = { showAboutDialog = false }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E2C)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("About", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        IconButton(onClick = { showAboutDialog = false }) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Gray)
                        }
                    }
                    HorizontalDivider(color = Color.DarkGray, modifier = Modifier.padding(vertical = 8.dp))
                    Text(
                        text = "Badge Control v1.0\n\nApp for logo badge control via BLE UART.\n\nProvides communication with device showing images and animations.\n\nAny questions, contact me: irziss2111@hotmail.com",
                        color = Color.LightGray,
                        fontSize = 14.sp
                    )
                }
            }
        }
    }

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = {
                Text(text = "Reset Device", color = Color.White, fontWeight = FontWeight.Bold)
            },
            text = {
                Text("Are you sure to reset device?", color = Color.LightGray)
            },
            containerColor = Color(0xFF1E1E2C),
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.sendCommand("reset")
                        showResetDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F))
                ) {
                    Text("Reset")
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) {
                    Text("Cancel", color = Color.Gray)
                }
            }
        )
    }

    if (showTerminalDialog) {
        TerminalDialog(
            viewModel = viewModel,
            onDismiss = { showTerminalDialog = false }
        )
    }
}

// -------------------------------------------------------------------
// ДИАЛОГ ВЫБОРА RGB ЦВЕТА
// -------------------------------------------------------------------
@Composable
fun ColorPickerDialog(
    defaultColorHex: String = "F800",
    onColorSelected: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var redVal by remember { mutableFloatStateOf(1f) }
    var greenVal by remember { mutableFloatStateOf(0f) }
    var blueVal by remember { mutableFloatStateOf(0f) }

    val currentColor = Color(redVal, greenVal, blueVal)

    val presetColors = listOf(
        Color.Red, Color.Green, Color.Blue,
        Color.Yellow, Color.Cyan, Color.Magenta,
        Color.White, Color(0xFFFF8C00)
    )

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E2C)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Color Palette", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Gray)
                    }
                }

                HorizontalDivider(color = Color.DarkGray, modifier = Modifier.padding(vertical = 8.dp))

                // Предпросмотр текущего цвета и Hex RGB565 кода
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(vertical = 8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(currentColor)
                            .border(2.dp, Color.White, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Text(
                        text = "HEX (RGB565): #${currentColor.toRgb565Hex()}",
                        color = Color.LightGray,
                        fontSize = 14.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                // Быстрые пресеты
                LazyVerticalGrid(
                    columns = GridCells.Fixed(4),
                    modifier = Modifier.height(80.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(presetColors) { color ->
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(color)
                                .clickable {
                                    redVal = color.red
                                    greenVal = color.green
                                    blueVal = color.blue
                                }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // RGB Слайдеры
                Text("Red", color = Color.Red, fontSize = 12.sp)
                Slider(
                    value = redVal,
                    onValueChange = { redVal = it },
                    colors = SliderDefaults.colors(thumbColor = Color.Red, activeTrackColor = Color.Red)
                )

                Text("Green", color = Color.Green, fontSize = 12.sp)
                Slider(
                    value = greenVal,
                    onValueChange = { greenVal = it },
                    colors = SliderDefaults.colors(thumbColor = Color.Green, activeTrackColor = Color.Green)
                )

                Text("Blue", color = Color.Blue, fontSize = 12.sp)
                Slider(
                    value = blueVal,
                    onValueChange = { blueVal = it },
                    colors = SliderDefaults.colors(thumbColor = Color.Blue, activeTrackColor = Color.Blue)
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Кнопки
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(
                        onClick = { onColorSelected(defaultColorHex) }
                    ) {
                        Text("Default (F800)", color = Color.Gray)
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = { onColorSelected(currentColor.toRgb565Hex()) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1976D2))
                    ) {
                        Text("Apply")
                    }
                }
            }
        }
    }
}

@Composable
fun PageGrid(
    pageIndex: Int,
    imageStatus: ImageStatus?,
    imageLoader: ImageLoader,
    onItemClick: (BadgeItem) -> Unit
) {
    val itemsList = remember(pageIndex) { getPageItems(pageIndex) }

    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(items = itemsList, key = { it.id }) { item ->
            val currentStatus = if (imageStatus?.imageIndex == item.id) {
                imageStatus.isSuccess
            } else null

            AnimatedImageCard(
                title = item.title,
                imageResId = item.imageResId,
                status = currentStatus,
                imageLoader = imageLoader,
                onClick = { onItemClick(item) }
            )
        }
    }
}

@Composable
fun AnimatedImageCard(
    title: String,
    imageResId: Int,
    status: Boolean?,
    imageLoader: ImageLoader,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(160.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E))
    ) {
        Box(
            modifier = Modifier.fillMaxSize()
        ) {
            AsyncImage(
                model = imageResId,
                contentDescription = title,
                imageLoader = imageLoader,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp),
                contentScale = ContentScale.Fit
            )

            if (status != null) {
                val backgroundColor = if (status) Color(0xEE2E7D32) else Color(0xEED32F2F)
                val textToShow = if (status) "INSTALLED" else "ERROR"

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight(0.3f)
                        .align(Alignment.BottomCenter)
                        .background(backgroundColor),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = textToShow,
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
fun TerminalDialog(
    viewModel: BleViewModel,
    onDismiss: () -> Unit
) {
    val logs by viewModel.logs.collectAsState()
    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(logs.size) {
        if (logs.isNotEmpty()) {
            listState.animateScrollToItem(logs.size - 1)
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F0F14)),
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .fillMaxHeight(0.8f)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("BLE UART Terminal", color = Color(0xFF00E676), fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                    }
                }

                HorizontalDivider(color = Color.DarkGray, modifier = Modifier.padding(bottom = 8.dp))

                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .background(Color(0xFF050508), shape = RoundedCornerShape(8.dp))
                        .padding(8.dp)
                ) {
                    items(logs) { log ->
                        val prefix = if (log.isSent) "TX -> " else "RX <- "
                        val color = if (log.isSent) Color(0xFF64B5F6) else Color(0xFF81C784)
                        val displayText = log.text.ifEmpty { " " }

                        Text(
                            text = "$prefix$displayText",
                            color = color,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(vertical = 1.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Write command...", color = Color.Gray, fontSize = 12.sp) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF1976D2),
                            unfocusedBorderColor = Color.DarkGray,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    IconButton(
                        onClick = {
                            if (inputText.isNotBlank()) {
                                viewModel.sendCommand(inputText)
                                inputText = ""
                            }
                        },
                        modifier = Modifier
                            .background(Color(0xFF1976D2), shape = RoundedCornerShape(8.dp))
                            .size(48.dp)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
fun PermissionRequester(content: @Composable () -> Unit) {
    val context = LocalContext.current

    val requiredPermissions = remember {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }
    }

    var permissionsGranted by remember {
        mutableStateOf(hasPermissions(context, requiredPermissions))
    }

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        permissionsGranted = result.values.all { it }
    }

    // Notification permission is optional for BLE itself, so declining it must not block the UI.
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { }

    LaunchedEffect(Unit) {
        if (!permissionsGranted) {
            launcher.launch(requiredPermissions)
        }
    }

    LaunchedEffect(permissionsGranted) {
        if (permissionsGranted && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    if (permissionsGranted) {
        content()
    } else {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Need permissions for Bluetooth", color = Color.White)
        }
    }
}

private fun hasPermissions(context: Context, permissions: Array<String>): Boolean {
    return permissions.all {
        ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
    }
}
