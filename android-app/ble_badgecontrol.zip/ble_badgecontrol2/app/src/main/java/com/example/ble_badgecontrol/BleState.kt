package com.example.ble_badgecontrol // <-- ТВОЁ ИМЯ ПАКЕТА

sealed class BleState {
    object Disconnected : BleState()
    object Scanning : BleState()
    object Connecting : BleState()
    data class Connected(val deviceName: String) : BleState()
    data class Error(val message: String) : BleState()
}